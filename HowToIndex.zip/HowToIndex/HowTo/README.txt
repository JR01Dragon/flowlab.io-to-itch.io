Extract the HowToIndex.zip folder.
 - Right click the folder
 - click "Extract All..."
 - On the pop-up, check the checkbox "Open extracted files when complete"
 - click "Extract"
 - Open the "HowTo" Folder

Follow the steps of instructions in "HowTo.txt" file.

If the file just shows "HowTo", then it would be best to show extension names.
 - At the top of the File Explorer, click "View"
 - Check the Checkbox with "File name extensions"