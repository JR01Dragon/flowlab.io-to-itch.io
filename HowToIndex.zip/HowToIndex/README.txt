1. How to extract the HowToIndex.zip:
 - Right click "HowToIndex.zip"
 - click "Extract All..."
 - Check the checkbox "Open extracted files when complete"
 - click "Extract"
 - Open the "HowToIndex" Folder

2. If the index file just shows "index" instead of "index.txt", 
then then you need to show extension names:
 - At the top of the File Explorer, click "View"
 - Check the Checkbox with "File name extensions"

3. Follow the steps of instructions in "HowTo" file.